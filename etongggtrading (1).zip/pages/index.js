import Head from "next/head";

export default function Home() {
  return (
    <>
      <Head>
        <title>EtongggTrading</title>
      </Head>
      <main style={{ padding: "20px", fontFamily: "Arial" }}>
        <h1>🚀 Welcome to EtongggTrading</h1>
        <p>Your real-time crypto chart & signals platform</p>

        {/* BTC TradingView Chart */}
        <div style={{ marginTop: 20 }}>
          <h2>📊 Bitcoin Live Chart</h2>
          <iframe
            src="https://s.tradingview.com/widgetembed/?frameElementId=tradingview_4f89a&symbol=BINANCE:BTCUSDT&interval=1&hidesidetoolbar=1&theme=dark"
            width="100%"
            height="400"
            frameBorder="0"
          ></iframe>
        </div>

        {/* Sample signals */}
        <div style={{ marginTop: 40 }}>
          <h2>✅ Entry Strategy</h2>
          <p>LONG Signal on BTC/USDT at $62,000 (based on RSI oversold)</p>
          <p>SHORT Signal on ETH/USDT at $3,300 (bearish divergence)</p>
        </div>

        {/* Altseason status */}
        <div style={{ marginTop: 40, color: "lime" }}>
          <h2>🌊 ALTSEASON ACTIVE</h2>
        </div>

        {/* Bybit affiliate button */}
        <div style={{ marginTop: 50 }}>
          <a
            href="https://www.bybit.com/invite?ref=YXVD2R"
            target="_blank"
            style={{
              background: "#f7931a",
              color: "#fff",
              padding: "10px 20px",
              borderRadius: "10px",
              textDecoration: "none",
              fontWeight: "bold",
            }}
          >
            🔗 Join Bybit with My Link
          </a>
        </div>
      </main>
    </>
  );
}
